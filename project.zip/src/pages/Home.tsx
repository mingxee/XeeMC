import React from 'react';
import { Users, Server, MessageSquare } from 'lucide-react';
import { Card } from '../components/Card';
import { ServerInfo } from '../components/ServerInfo';
import { FeatureCard } from '../components/FeatureCard';

export function Home() {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16 animate-fade-in">
          <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
            Welcome to XeeMC
          </h1>
          <p className="text-xl text-gray-300">Experience Minecraft like never before!</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          <ServerInfo />
          
          <Card>
            <h2 className="text-2xl font-bold mb-4">Join Our Community</h2>
            <p className="text-gray-300 mb-6">
              To play on our server, you need to join our Discord community first!
            </p>
            <a
              href="https://discord.gg/"
              className="inline-flex items-center gap-2 bg-[#5865F2] hover:bg-[#4752C4] px-6 py-3 rounded-lg font-semibold transition-all duration-300 hover:shadow-lg hover:shadow-[#5865F2]/20"
            >
              <MessageSquare size={20} className="animate-bounce" />
              Join Discord
            </a>
          </Card>
        </div>

        <Card>
          <h2 className="text-2xl font-bold mb-6 text-center">Server Features</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <FeatureCard
              icon={<Users className="w-full h-full" />}
              title="Cross-Play"
              description="Play with friends on both Java and Bedrock editions"
            />
            <FeatureCard
              icon={<Server className="w-full h-full" />}
              title="24/7 Uptime"
              description="Server is always online and ready to play"
            />
            <FeatureCard
              icon={<MessageSquare className="w-full h-full" />}
              title="Active Community"
              description="Join our friendly community of players"
            />
          </div>
        </Card>
      </div>
    </div>
  );
}